<h1 align="center">
  ♻️RECICLE
</h1>

<h1>
<img src="public/Video.gif">
</h1>

## 📂 Sobre

O projeto **Recicle** é um site para solicitação de material como entulho, material infeccioso e quimicos. Foi criado no intuito de colocarmos em pratica todo conteudo estudado da faculdade do **projeto integrador**.

## 🚀 Tecnologias utilizadas

O projeto foi desenvolvido utilizando as seguintes tecnologias

- Html
- Css

## 📁 Como baixar o projeto


 ```bash
$ git clone 

$ cd Recicle

$ yarn install

$ yarn start
 ```